import unittest
import requests

def http_request(url, headers):
    if (url != '' and headers != {}):
        return requests.get(url,timeout=15, headers=headers)

    return {}

class TestFactorial(unittest.TestCase):
    """
    Our basic test class
    """

    def test_http_request(self):
        """
        The actual test.
        Any method which starts with ``test_`` will considered as a test case.
        """

        url = "https://www.atptour.com/en/rankings/singles?rankRange=0-200"
        # url = urlpattern.format(date)
        headers={'User-Agent': ''}
        res = http_request(url, headers)
        self.assertEqual(res.status_code, 200)


if __name__ == '__main__':
    unittest.main()                     